<?php
        
            $dbhost = 'db';
            $dbuser = 'root';
            $dbpass = 'mypass123';
	    $dbname='server';
	    $tablename = $argv[1];
	    $csvfile = $argv[2];
	    $truncate = $argv[3];
           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
    		die("Connection failed: " . mysqli_connect_error());
	   }
	   if ( $truncate == "yes" ) {
		   mysqli_query($conn, "TRUNCATE TABLE `$tablename`");
}
	$sql = "LOAD DATA INFILE './$csvfile' into table
    $tablename fields terminated by ','
    optionally enclosed by '\"'
    lines
    terminated by '\n'";
if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
          
