<html>
<head>
<script>
history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
	</script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.back {
	color:black;
	display:inline-block;
	background: rgba(0,0,0, 0.3);
	padding:6px 16px;
	
	font-weight:bold;
}
.home{
	color:black;
	display:inline-block;
    float:right;
	background: rgba(0,0,0, 0.3);
	padding:6px 16px;
	
	font-weight:bold;
}
a.back:link,a.back:visited
{
	color:black;
}
a.home:link,a.home:visited
{
	color:black;
}
.memory {
	
	position:relative;
	 background: rgba(0,0,0, 0.3);
}

table, th, td {
border: 1px solid black;"
}
 h2{
	margin-left: 10%;
}

body {
  font-family: "Lato", sans-serif;
  background: rgba(0,0,0, 0.01);
  
}
.back1{
	margin-left:10px;
	bottom:0;
	
}
.buttons1{
	float:left;
	padding:2px 8px;
}
</style>
<body>
<?php
echo "<style>";
echo "table, th, td {";
echo "border: 1px solid black;";
echo "}";
echo "</style>";
$servname= $_GET['servname'];

$dbhost = 'db';
            $dbuser = 'root';
            $dbpass = 'mypass123';
            $dbname='server';
           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            }
            $sql = "SELECT Servername,TotalRAM,FreeRAM,RpoolSpace,DpoolSpace,FreeRAMper,ZonesAvailable,ZonesAccom,BEname from finalserver where Servername='$servname'";

            $result = mysqli_query($conn, $sql);
            
while($row = mysqli_fetch_assoc($result)) {
    // Each individual array is being pushed into the nested array
    
        $hostname=$row["Servername"];
        $totalmem=$row["TotalRAM"];
        $freemem=$row["FreeRAM"];
        $rpoolspace=$row["RpoolSpace"];
        $dpoolspace=$row["DpoolSpace"];
        $freeram=$row["FreeRAMper"];
        $zonesavail=$row["ZonesAvailable"];
        $zonesaccom=$row["ZonesAccom"];
        $be=$row["BEname"];
		echo "<h1>Details of server $servname:</h1>";
		echo "<div class=\"memory\">";
        echo "<table style=width:100%>";
        echo "<tr>";
        echo "<th>HostName</th>";
        echo "<th>Total memory</th>";
        echo "<th>Free memory</th>";
        echo "<th>Rpool space</th>";
        echo "<th>Dpool space</th>";
        echo "<th>FreeRAM(%)</th>";
        echo "<th>Number of Zones Available</th>";
        echo "<th>No of Zones to accomodate space</th>";
        echo "<th>Current BE</th>";
        echo "</tr>";
        echo "<tr>";
        echo "<td align=\"center\">$hostname</td>";
        echo "<td align=\"center\">$totalmem</td>";
        echo "<td align=\"center\">$freemem</td>";
        echo "<td align=\"center\">$rpoolspace</td>";
        echo "<td align=\"center\">$dpoolspace</td>";
        echo "<td align=\"center\">$freeram</td>";
        echo "<td align=\"center\">$zonesavail</td>";
        echo "<td align=\"center\">$zonesaccom</td>";
        echo "<td align=\"center\">$be</td>";

        echo "</tr>";
        echo "</table>";

        #print_r($zonenames);
        #print_r($totalmem);
        #$new = $data[2],$data[3],$data[4];
        #$arrayph = explode(":",$new);
        #foreach($arrayph as $i)
        #{
        #       echo "<li><a href=#>$i</a></li>";
        #}

        #$trimmed = str_replace(":",",",$new);
        #$array1 = array($trimmed);
        #print_r($array1[0]);

#    $the_big_array[] = $data;
  }

  // Close the file
  mysqli_close($conn);
#echo "xxx\n";
#print_r($the_big_array[1][0]);
#echo "<pre>";
#var_dump($the_big_array);

#echo "</pre>";
?>
</div>
<br>


<a   href="listofservers.php" class="back">Back</a> 
<a   href="new.php" class="home">Home</a>



</body>
</html>
