<!DOCTYPE html>
<html>
<head>


<title>Webslesson Tutorial | Search HTML Table Data by using JQuery</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
            
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  
  <script>
history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
     $(document).ready(function(){  
           $('#search').keyup(function(){  
                search_table($(this).val());  
           });  
           function search_table(value){  
                $('#employee_table tr').each(function(){  
                     var found = 'false';  
                     $(this).each(function(){  
                          if($(this).text().toLowerCase().indexOf(value.toLowerCase()) >= 0)  
                          {  
                               found = 'true';  
                          }  
                     });  
                     if(found == 'true')  
                     {  
                          $(this).show();  
                     }  
                     else  
                     {  
                          $(this).hide();  
                     }  
                });  
           }  
      });  
  </script>
  <style>
    .home{
  color:black;
  display:inline-block;
  background: rgba(0,0,0, 0.3);
  padding:6px 20px;
  
  font-weight: bold;
  float:right;
}
a.home:link,a.home:visited
{
  color:black;
}
table, th, td {
  border: 1px solid black;
}
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</style>
<h1>DiskStatus:</h1>
<a href="new.php" class="home">Home</a>
<br>
<br>
<div align="center" >
<input type="text" placeholder="Search" name="" id="search" style="width:25vw;border: 1px solid black">
</div>
<br>
 <table class="table table-bordered" style=width:100%>
       <tr>
        <th align="center" col width="98">Servername</th>
         <th align="center" col width="2">Diskname</th>
        <th align="center" col width="501">DiskDetails</th>
        <th align="center" col width="78">Health</th>
        
      </tr>

      </table>
      <table class="table table-bordered" style=width:100% id="employee_table">

<?php
#$servname= 'server1';
$dbhost = 'db';
            $dbuser = 'root';
            $dbpass = 'mypass123';
            $dbname='server';

           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            }
            
       
             $sql1 = "SELECT DISTINCT Servername from diskstat";
             $result1=mysqli_query($conn, $sql1);
             while($row = mysqli_fetch_assoc($result1)) {
                $servname=$row["Servername"];
            $sql = "SELECT Diskname,Details,Health from diskstat where Servername='$servname'";
             
            $result = mysqli_query($conn, $sql);
          
while($row = mysqli_fetch_assoc($result)) {
    // Each individual array is being pushed into the nested array
         $diskname=$row["Diskname"];
         $details=$row["Details"];
        $health=$row["Health"];
        if ($health == "healthy")
        {
            $bgclr="background-color:#00FF00";

        } else {
             $bgclr="background-color:#FF0000";
        }
         
       #echo "<h1>Memory Details of server $servname:</h1>";
        #echo "<div class=\"main1\">";
        echo "<tr>";
        echo "<td align=\"center\" >$servname</td>";
        echo "<td align=\"center\" >$diskname</td>";
        echo "<td align=\"center\">$details</td>";
        echo "<td style= \"$bgclr\" ; align=\"center\">$health</td>";
        echo "</tr>";
        
         
     }
     
 }
 echo "</table>";
?>
<script>
     $(document).ready(function(){  
           $('#search').keyup(function(){  
                search_table($(this).val());  
           });  
           function search_table(value){  
                $('#employee_table tr').each(function(){  
                     var found = 'false';  
                     $(this).each(function(){  
                          if($(this).text().toLowerCase().indexOf(value.toLowerCase()) >= 0)  
                          {  
                               found = 'true';  
                          }  
                     });  
                     if(found == 'true')  
                     {  
                          $(this).show();  
                     }  
                     else  
                     {  
                          $(this).hide();  
                     }  
                });  
           }  
      });  
      </script>
