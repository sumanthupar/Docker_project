<!DOCTYPE html>
<html>
<head>
<script>
history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
	</script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.back {
	color:black;
	display:inline-block;
	background: rgba(0,0,0, 0.3);
	padding:6px 16px;
	
	font-weight:bold;
}
.home{
	color:black;
	display:inline-block;
	background: rgba(0,0,0, 0.3);
	padding:6px 16px;
	
	font-weight:bold;
}
a.back:link,a.back:visited
{
	color:black;
}
a.home:link,a.home:visited
{
	color:black;
}
.memory {
	position:relative;
	margin:0px;
	font-size:15px;
	color:inherit;
    
}
.memory a:link, a:visited a:active{
	color:blue;
}

body {
  font-family: "Lato", sans-serif;
   background: rgba(0,0,0, 0.01);
  
}
.buttons1{
	float:center;
	padding:2px 8px;
}
a:link, a:visited {
	color:blue;
}

</style>
<h1> 
<body>
<?php
//$servname= $_GET['testNum'];
$servname= $_GET['testNum'];


echo "<h1>List of zones on server $servname:</h1>";

echo "<div class=\"memory\">";
$dbhost = 'db';
            $dbuser = 'root';
            $dbpass = 'mypass123';
            $dbname='server';
           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            }
            $sql = "SELECT zonenames from finalserver where Servername='$servname'";
            $result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)) {
    // Each individual array is being pushed into the nested array
        #$zonenames=$data[1];
        #$totalmem=$data[2];
#       $freemem=$data[3];
        #print_r($zonenames);
        #print_r($totalmem);
  
        $new = $row["zonenames"];
        $arrayph = explode(":",$new);
        foreach($arrayph as $i)
        {
                echo "<li><a href=\"getzonedetails.php?testserv=$i\">$i</li><br>";
        }

        #$trimmed = str_replace(":",",",$new);
        #$array1 = array($trimmed);
        #print_r($array1[0]);

#    $the_big_array[] = $data;
  }

  // Close the file
  mysqli_close($conn);
#echo "xxx\n";
#print_r($the_big_array[1][0]);
#echo "<pre>";
#var_dump($the_big_array);

#echo "</pre>";
?>
</div>

<br>

<a   href="listofservers.php" class="back">Back</a> 
<a   href="new.php" class="home">Home</a>




</body>
</html>

