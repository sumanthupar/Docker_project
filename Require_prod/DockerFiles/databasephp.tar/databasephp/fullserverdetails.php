<html>
<head>
  <title>Webslesson Tutorial | Search HTML Table Data by using JQuery</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
            
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  
  <script>
history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
     $(document).ready(function(){  
           $('#search').keyup(function(){  
                search_table($(this).val());  
           });  
           function search_table(value){  
                $('#employee_table tr').each(function(){  
                     var found = 'false';  
                     $(this).each(function(){  
                          if($(this).text().toLowerCase().indexOf(value.toLowerCase()) >= 0)  
                          {  
                               found = 'true';  
                          }  
                     });  
                     if(found == 'true')  
                     {  
                          $(this).show();  
                     }  
                     else  
                     {  
                          $(this).hide();  
                     }  
                });  
           }  
      });  
  </script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

.home{
  color:black;
  display:inline-block;
  background: rgba(0,0,0, 0.3);
  padding:6px 16px;
 
  font-weight: bold;
  float:right;
}
a.home:link,a.home:visited
{
  color:black;
}
table, th, td {
border: 1px solid black;

}


body {
  font-family: "Lato", sans-serif;
background: rgba(0,0,0, 0.01);
  
  

a {
  float:right;
  
}
}
</style>
<body>

<h1>All zone Details:</h1>
<a href="new.php" class="home">Home</a>
<br>
<br>
<div align="center" >
<input type="text" placeholder="Search" name="" id="search" style="width:25vw;border: 1px solid black">
</div>
<br>

      
 
    <div class="table-responsive" > 
      <table class="table table-bordered" style=width:100%>
       <tr>
        <th align="center" col width="40">Sl.No</th>
         <th align="center" col width="183">Servername</th>
        <th align="center" col width="247">Totalname</th>
        <th align="center" col width="155">FreeRAM(GB)</th>
        <th align="center" col width="173">Rpool space</th>
        <th align="center" col width="200">Dpool space</th>
        <th align="center" col width="200">FreeRAM per</th>
        <th align="center" col width="173">No of ZonesAvailable</th>
        <th align="center" col width="232">No of Zones Accom</th>
        <th align="center" col width="232">BEname</th>
      </tr>

      </table>
      <table class="table table-bordered" style=width:100% id="employee_table">
  

      
<?php
$i=0;
$dbhost = 'db';
            $dbuser = 'root';
            $dbpass = 'mypass123';
            $dbname='server';
           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            }
             $sql = "SELECT Servername,TotalRAM,FreeRAM,RpoolSpace,DpoolSpace,FreeRAMper,ZonesAvailable,ZonesAccom,BEname from finalserver";
             $result = mysqli_query($conn, $sql);

             while($row = mysqli_fetch_assoc($result)) {
    // Each individual array is being pushed into the nested array
       
        $servername=$row["Servername"];
        $tram=$row["TotalRAM"];
        $fram=$row["FreeRAM"];
        $rpspace=$row["RpoolSpace"];
        $dpspace=$row["DpoolSpace"];
        $framper=$row["FreeRAMper"];
        $znavail=$row["ZonesAvailable"];
        $znac=$row["ZonesAccom"];
        $benm=$row["BEname"];
        
        echo "<tr>";
        echo "<td align=\"center\" col width=\"56\">$i</td>";
        echo "<td align=\"center\" col width=\"183\">$servername</td>";
        echo "<td align=\"center\" col width=\"247\">$tram</td>";
        echo "<td align=\"center\" col width=\"172\">$fram</td>";
        echo "<td align=\"center\" col width=\"150\">$rpspace</td>";
        echo "<td align=\"center\" col width=\"160\">$dpspace</td>";
        echo "<td align=\"center\" col width=\"200\">$framper</td>";
        echo "<td align=\"center\" col width=\"240\">$znavail</td>";
        echo "<td align=\"center\" col width=\"232\">$znac</td>";
        echo "<td align=\"center\" col width=\"232\">$benm</td>";
        

        echo "</tr>";
       
       $i++; 

        #print_r($zonenames);
        #print_r($totalmem);
        #$new = $data[2],$data[3],$data[4];
        #$arrayph = explode(":",$new);
        #foreach($arrayph as $i)
        #{
        #       echo "<li><a href=#>$i</a></li>";
        #}

        #$trimmed = str_replace(":",",",$new);
        #$array1 = array($trimmed);
        #print_r($array1[0]);

#    $the_big_array[] = $data;
  }

  // Close the file
  mysqli_close($conn);
#echo "xxx\n";
#print_r($the_big_array[1][0]);
#echo "<pre>";
#var_dump($the_big_array);

#echo "</pre>";
  
?>
</table>
</div><br>

<script>
     $(document).ready(function(){  
           $('#search').keyup(function(){  
                search_table($(this).val());  
           });  
           function search_table(value){  
                $('#employee_table tr').each(function(){  
                     var found = 'false';  
                     $(this).each(function(){  
                          if($(this).text().toLowerCase().indexOf(value.toLowerCase()) >= 0)  
                          {  
                               found = 'true';  
                          }  
                     });  
                     if(found == 'true')  
                     {  
                          $(this).show();  
                     }  
                     else  
                     {  
                          $(this).hide();  
                     }  
                });  
           }  
      });  
</script>
</body>
</html>
