<!DOCTYPE html>
<html>
<head>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
 </head>
<script>
history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
  </script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.home{
  color:black;
  display:inline-block;
  background: rgba(0,0,0, 0.3);
  padding:4px 10px;
  
  font-weight:bold;
}
a.home:link,a.home:visited
{
  color:black;
}

.sidenav {
  height: 100%;
  width: 300px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 15px;
}
 h3{
  margin-top:6px;
  color:white;
  margin-left: 15px;
}
h2{
  margin-top:40px;
}
.fa-caret-down {
  float: right;
  padding-right: 80px;
}
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 16px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width: 100%;
  text-align: left;
  cursor: pointer;
  outline: none;
}
.active {
  background-color: green;
  color: white;
}


.dropdown {
  position: relative;
  display: block;
  padding : 10px;
  
 
}

.dropdown-content {
  display:none;
  float:right;
  background-color:#262626;
  padding-right: 18px;
}

.dropdown-content a {
  color: green;
  padding: 8px px;
  text-decoration: none;
  display: block;
}
.sidenav a:hover, .dropdown-btn:hover {
  color: #f1f1f1;
}
.main a:link, a:visited a:active{
  float:right;
  color:blue;
  
}
</style>
</head>
<body>
<div class="main">
<a   href="new.php" class="home">Home</a>
<div class="container">
    <canvas id="myChart"></canvas>
  
</div>  
</div>
<div class="sidenav">
<h3>CloudServers</h3>
<?php
 $usedrams=[];
        $zonenamess=[];
        $totalrams=[];
        
        $new='';
        $new1='';
        $new4='';
$dbhost = 'db';
            $dbuser = 'root';
            $dbpass = 'mypass123';
            $dbname='server';
           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            }
            $sql = "SELECT Servername from finalserver ";
            $sql1="SELECT Servername,FreeRAM,TotalRAM from finalserver order by FreeRAM DESC";
            $result = mysqli_query($conn, $sql);
            $result1 = mysqli_query($conn, $sql1);
while($row = mysqli_fetch_assoc($result)) {

    
    $servname=$row["Servername"];
    echo "<button class=\"dropdown-btn\">$row[Servername]<i class=\"fa-caret-down\"></i></button>";
    echo "<div class=\"dropdown-content\">";
        echo "<a href=\"listzoneofservers.php?testNum=$servname\">ListZones</a>";
        echo "<a href=\"getmemorydetails.php?testser=$servname\">Memory Details</a>";
        echo "<a href=\"Allinall.php?servname=$servname\">AllDetails</a>";
    
     echo "</div>";

  }
 while($rows = mysqli_fetch_assoc($result1)) {
         
              array_push($zonenamess, $rows["Servername"]);
                array_push($usedrams, $rows["FreeRAM"]);
                array_push($totalrams, $rows["TotalRAM"]);

             
              }

               $new = "'".implode("','", $zonenamess)."'";
               
                $new2=implode(",", $usedrams);
                $new1=preg_replace('/[^0-9,.]+/i', '', $new2);
                $new3=implode(",", $totalrams);
                $new4=preg_replace('/[^0-9,.]+/i', '', $new3);
                

 mysqli_close($conn);
#$newvar=$the_big_array;

echo "</ul>";
?>
 </div>
 <script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}

 let myChart = document.getElementById('myChart').getContext('2d');

    Chart.defaults.global.defaultFontFamily = 'Lato';
    Chart.defaults.global.defaultFontSize = 18;
    Chart.defaults.global.defaultFontColor = '#777';

    let massPopChart = new Chart(myChart, {
      type:'bar', // bar, horizontalBar, pie, line, doughnut, radar, polarArea
      data:{
        labels:[<?php echo $new; ?>],
        datasets:[{
          label:"TotalRAM",
          backgroundColor:'rgba(54, 162, 235, 0.8)',
          data:[<?php echo $new4; ?>],
        },{
          label:"FreeRAM",
          backgroundColor:'rgba(255, 99, 132, 1)',
          data:[<?php echo $new1; ?>],
        }
        ]
      },
      options:{
        
        title:{
          display:true,
          text:'Free RAM Available chart',
          fontSize:25
        },
        scales: {
        xAxes: [{barPercentage: 0.4,
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'ServerNames'
                            }
                        }],
                    yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'FreeRAM in GB'
                            },
                            ticks: {
                                
                              
                               min:0,
                               stepsize:3,
                              
                                
                            }
                        }]
      },

        legend:{
          display:true,
          
          labels:{
            fontColor:'#000'
          }
        },
        layout:{
          padding:{
            left:300,
            right:-100,
            bottom:10,
            top:10
          }
        },
        tooltips:{
          enabled:true
        }
      }
    });

  
</script>
</body>
</html>

