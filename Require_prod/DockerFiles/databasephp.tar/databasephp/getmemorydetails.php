<!DOCTYPE html>
<html>
<head>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script>
</head>
<script>
history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
    </script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.back {
    color:black;
    display:inline-block;
    background: rgba(0,0,0, 0.3);
    padding:6px 16px;
    
    font-weight:bold;
    
}
.home{
    color:black;
    display:inline-block;
    background: rgba(0,0,0, 0.3);
    padding:6px 16px;
    float: right;
    font-weight:bold;
}
a.back:link,a.back:visited
{
    color:black;
}
a.home:link,a.home:visited
{
    color:black;
}
    
.memory {
    position:relative;
    background: rgba(0,0,0, 0.3);
    
    
        
}

.container .myChart{
    max-height: 10px;
}

table, th, td {
border: 1px solid black;"
}
 h2{
    margin-left: 10%;
}


.buttons1{
    float:left;
    padding:2px 8px;
}
</style>

<body>




<?php
$servname= $_GET['testser'];
list($x,$y)=testfun("1 hour",$servname);
if(isset($_POST['submit'])) 
{
      $coder=$_POST['coder'];
      list($x,$y)=testfun($coder,$servname);
      

}

#$servname= 'canopus';

$dbhost = 'db';
            $dbuser = 'root';
            $dbpass = 'mypass123';
            $dbname='server';
           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            }
            $sql = "SELECT TotalRAM,FreeRAM,RpoolSpace,DpoolSpace,FreeRAMper from finalserver where Servername='$servname'";
            $result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)) {
    // Each individual array is being pushed into the nested array
        #$zonenames=$data[1];
        $totalmem=$row["TotalRAM"];
        $freemem=$row["FreeRAM"];
        $rpoolspace=$row["RpoolSpace"];
        $dpoolspace=$row["DpoolSpace"];
        $freeram=$row["FreeRAMper"];
        
        echo "<h1>Memory Details of server $servname:</h1>";
        #echo "<div class=\"main1\">";
        echo "<div class=\"memory\">";
        echo "<table style=width:100%>";
        echo "<tr>";
        echo "<th>Total memory</th>";
        echo "<th>Free memory</th>";
        echo "<th>Rpool space</th>";
        echo "<th>Dpool space</th>";
        echo "<th>FreeRAM(%)</th>";
        echo "</tr>";
        echo "<tr>";
        echo "<td align=\"center\">$totalmem</td>";
        echo "<td align=\"center\">$freemem</td>";
        echo "<td align=\"center\">$rpoolspace</td>";
        echo "<td align=\"center\">$dpoolspace</td>";
        echo "<td align=\"center\">$freeram</td>";
        echo "</tr>";
        echo "</table>";
                
        #print_r($zonenames);
        #print_r($totalmem);
        #$new = $data[2],$data[3],$data[4];
        #$arrayph = explode(":",$new);
        #foreach($arrayph as $i)
        #{
        #       echo "<li><a href=#>$i</a></li>";
        #}

        #$trimmed = str_replace(":",",",$new);
        #$array1 = array($trimmed);
        #print_r($array1[0]);

#    $the_big_array[] = $data;
        mysqli_close($conn);
  }
   

function testfun($country,$servname){


  
    $new='';
    $new1='';
    $usedrams=[];
    $zonenamess=[];
        
        
            
            $dbhost = 'db';
            $dbuser = 'root';
            $dbpass = 'mypass123';
            $dbname='server';
           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            }

          # $sql1="SELECT Servername,FreeRAM from serverdetailsback1 where Servername='$servname' order by FreeRAM DESC LIMIT 10";
            $sql1="SELECT datatime,FreeRAM from finalserverback1 where Servername='$servname' AND datatime < DATE_SUB(NOW(), interval $country)";
           
            $result1 = mysqli_query($conn, $sql1);
  while($rows = mysqli_fetch_assoc($result1)) {
         
              array_push($zonenamess, $rows["datatime"]);
                array_push($usedrams, $rows["FreeRAM"]);

             
              }

               $new = "'".implode("','", $zonenamess)."'";
               
                $new2=implode(",", $usedrams);
                $new1=preg_replace('/[^0-9,.]+/i', '', $new2);
                return array($new, $new1);

  // Close the file
  mysqli_close($conn);
#echo "xxx\n";
#print_r($the_big_array[1][0]);
#echo "<pre>";
#var_dump($the_big_array);

#echo "</pre>";
}
?>
</div>
</div>

<br>

<a  href="listofservers.php" class="back">Back</a> 
<a  href="new.php" class="home">Home</a>

<br><br>

<form action=""; method="post" name="myform" id="myform" style="position:relative;left:1000px;">
    
    Graph over Last
  <select name="coder">     
       <option value="1 hour">1 hour</option>
        <option value="3 hour">3 hour</option>
        <option value="5 hour">5 hour</option>
        <option value="10 hour">10 hour</option>
        <option value="24 hour">24 hour</option>
        <option value="48 hour">48 hour</option>
    </select>
    <input type="submit" name="submit" value="submit">
  </form>

<div class="container" style="position: relative; height:65vh; width:75vw">
    <canvas id="myChart"></canvas>
  
</div> 

<script>
    let myChart = document.getElementById('myChart').getContext('2d');
   

    Chart.defaults.global.defaultFontFamily = 'Lato';
    Chart.defaults.global.defaultFontSize = 18;
    Chart.defaults.global.defaultFontColor = '#777';

    let massPopChart = new Chart(myChart, {
      type:'line', // bar, horizontalBar, pie, line, doughnut, radar, polarArea
      data:{
        labels:[<?php echo $x; ?>],
        datasets:[{
          fill:false,
          data:[<?php echo $y; ?>],
          //backgroundColor:'green',
          backgroundColor:[
            'rgba(255, 99, 132, 0.6)',
            'rgba(54, 162, 235, 0.6)',
            'rgba(255, 206, 86, 0.6)',
            'rgba(75, 192, 192, 0.6)',
            'rgba(153, 102, 255, 0.6)',
            'rgba(255, 159, 64, 0.6)',
            'rgba(255, 99, 132, 0.6)'
          ],
          borderWidth:1,
          borderColor:'#777',
          hoverBorderWidth:1,
          hoverBorderColor:'#000'
        }]
      },
      
      options:{
        
        title:{
          display:true,
          text:'Free RAM Available over intervals',
          fontSize:25,
        },
        scales: {
        xAxes: [{
                            display:true,
                           
                            scaleLabel: {
                              offset: true,
                                display: true,
                                labelString: 'ServerNames'
                            },
                            ticks: {
        minRotation: 70
      },
                        }],
                    yAxes: [{
                            stacked:true,
                            display: true,
                            scaleLabel: {
                               display: true,
                                padding:10,
                                labelString: 'UsedRAM in GB'
                            },
                            ticks: {
                                
                               
                               min:0,
                               stepsize:2
                              
                                
                            }
                        }]
      },

        legend:{
          display:true,
          position:'center',
          labels:{
            fontColor:'#000'
          }
        },
        layout:{
          padding:{
            left:100,
            right:0,
            bottom:50,
            top:20
          }
        },
        tooltips:{
          enabled:true
        }
      }
    });

  
</script>

</body>
</html>
