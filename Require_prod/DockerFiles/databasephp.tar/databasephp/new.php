<?php

        $usedram=[];
        $zonename=[];
        $new='';
        $new1='';
            $dbhost = 'db';
            $dbuser = 'root';
            $dbpass = 'mypass123';
            $dbname='server';
            $i=0;
           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
    		die("Connection failed: " . mysqli_connect_error());
			}
         
           // $sql = "SELECT usedram,zonename from zonedetails ORDER BY usedram DESC LIMIT 10" ; 
            $sql="SELECT usedram,zonename,zonehost FROM  zonedetails1 LIMIT 10 ";
            $result = mysqli_query($conn, $sql);

            while($row = mysqli_fetch_assoc($result)) {
         
              array_push($zonename, "$row[zonehost]/$row[zonename]");
                array_push($usedram, $row["usedram"]);

             
              }

               $new = "'".implode("','", $zonename)."'";
                $new1=implode(",", $usedram);
               

mysqli_close($conn);
?>
<html>
<head>
	<script>
history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
	</script>
		
		 <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700%7CPT+Serif:400,700,400italic' rel='stylesheet'>
		  <link href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans" rel="stylesheet">
		   <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>
<style>
	

	.menu{

	width: 100%;
	height: 55px;
	background-color: rgba(0,0,0,0.8);
}
.leftmenu{
	width: 30%;
	line-height: 100px;
	float: left;
	margin-top:20px;
/*	background-color: yellow;*/
}
.leftmenu h4{
	padding-left: 60px;
	font-weight: bold;
	color: white;
	font-size: 22px;
	font-family: 'Montserrat', sans-serif;
}
.rightmenu{
	width:70%;
	height: 100px;
	margin-top: -9px;
	float: right;
	
/*	background-color: red; */
}
.rightmenu ul{
	margin-left: 100px;
	
}
.rightmenu ul li {
	font-family: 'Montserrat', sans-serif;
	display: inline-block;
	list-style: none;
	font-size: 15px;
	color:white;
	font-weight: bold;
	line-height: 100px;
	margin-left: 20px;
	text-transform: uppercase;

}
.rightmenu ul li:hover{
	color: orange;
}
.text{
	width: 100%;
	margin-top: 185px;
	text-transform: uppercase;
	text-align: center;
	color:white;
}
.text h4{

	font-size: 14px;
	font-family: 'Open Sans', sans-serif;
	
}
	*{
	margin:0px;
	padding:0px;
}


</style>
<body>

	<div class="bgimage">
		<div class="menu">
			
			<div class="leftmenu">
				<h4> Serv&Zone </h4>
			</div>

			<div class="rightmenu">
				<ul>
					<li><a href="new.php" id="fisrtlist"> HOME </a></li>
					<li> <a href="listofservers.php">Inventory</a></li>
          				<li><a href="fullserverdetails.php">ServerLocator</a></li>
					<li><a href="fullzonedetails.php">ZoneLocator</a></li>
          				<li><a href="diskfetch.php">DiskStatus</a></li>
					<li> <a href="contact.html">Contact</a></li>
					<li> <a href="login.html">logout</a></li>
				</ul>
			</div>

		</div>
</div>

<div class="container">
    <canvas id="myChart"></canvas>
  
</div>

 <script>

    let myChart = document.getElementById('myChart').getContext('2d');

    Chart.defaults.global.defaultFontFamily = 'Lato';
    Chart.defaults.global.defaultFontSize = 18;
    Chart.defaults.global.defaultFontColor = '#777';

    let massPopChart = new Chart(myChart, {
      type:'bar', // bar, horizontalBar, pie, line, doughnut, radar, polarArea
      data:{
        labels:[<?php echo $new; ?>],
        datasets:[{
          label:'UsedRAMGB',
          data:[<?php echo $new1; ?>],
          //backgroundColor:'green',
          backgroundColor:[
            'rgba(255, 99, 132, 0.6)',
            'rgba(54, 162, 235, 0.6)',
            'rgba(255, 206, 86, 0.6)',
            'rgba(75, 192, 192, 0.6)',
            'rgba(153, 102, 255, 0.6)',
            'rgba(255, 159, 64, 0.6)',
            'rgba(255, 99, 132, 0.6)'
          ],
          borderWidth:1,
          borderColor:'#777',
          hoverBorderWidth:3,
          hoverBorderColor:'#000'
        }]
      },
      options:{
        
        title:{
          display:true,
          text:'Top 10 zones utilising high RAM',
          fontSize:25
        },
        scales: {
        xAxes: [{barPercentage: 0.4,
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Zonenames'
                            }
                        }],
                    yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'UsedRAM in GB'
                            },
                            ticks: {
                                
                               min:0,
                               stepsize: 5,
                               
                                
                            }
                        }]
      },

        legend:{
          display:true,
          position:'center',
          labels:{
            fontColor:'#000'
          }
        },
        layout:{
          padding:{
            left:50,
            right:0,
            bottom:0,
            top:0
          }
        },
        tooltips:{
          enabled:true
        }
      }
    });

  </script>

</body>
</html>
