<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
}

</style>
<?php
$servname= 'server1';
$dbhost = 'localhost:3306';
            $dbuser = 'root';
            $dbpass = '';
            $dbname='server';

           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            }
            $sql = "SELECT Details,Health from diskstat where Servername='$servname'";
             $sql1 = "SELECT DISTINCT Servername from diskstat";
             
            $result = mysqli_query($conn, $sql);
            $result1=mysqli_query($conn, $sql1);
print_r($result1);
           echo "<h1>Memory Details of server $servname:</h1>";
           echo "<table style=width:100% >";
        echo "<tr>";
        echo "<th>Server name</th>";
        echo "<th>Details</th>";
        echo "<th>Health</th>";
        echo "</tr>";
while($row = mysqli_fetch_assoc($result)) {
    // Each individual array is being pushed into the nested array
         $details=$row["Details"];
        $health=$row["Health"];
       #echo "<h1>Memory Details of server $servname:</h1>";
        #echo "<div class=\"main1\">";
        echo "<tr>";
        echo "<td align=\"center\">$servname</td>";
        echo "<td align=\"center\">$details</td>";
        echo "<td align=\"center\">$health</td>";
        echo "</tr>";
        
         
     }
     echo "</table>";
?>