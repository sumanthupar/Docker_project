<html>
<head>
     
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script>
 
</head>
<script>
history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
	</script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>


table, th, td {
border: 1px solid black;"
}
 h2{
	margin-left: 10%;
}
.back {
  color:black;
  display:inline-block;
  background: rgba(0,0,0, 0.3);
  padding:6px 16px;
  
  
  font-weight:bold;
  
}
.home {
  color:black;
  display:inline-block;
  background: rgba(0,0,0, 0.3);
  padding:6px 16px;
  float:right;
  
  font-weight:bold;
  
}

.back1{
	margin-left:10px;
	bottom:0;
	
}

.memory {
  
  position:relative;
   background: rgba(0,0,0, 0.3);
  
  
      
}
.buttons a:link, a:visited {
  color: black;
  padding: 15px 18px;
  text-align: center;
  text-decoration: none;
  
  margin-bottom:15px;
margin-top:15px;
}
</style>
<body>

<?php
$servname= $_GET['testserv'];
list($x,$y)=testfun("1 hour",$servname);
if(isset($_POST['submit'])) 
{
      $coder=$_POST['coder'];
      list($x,$y)=testfun($coder,$servname);
      

}

$serv=explode("-",$servname);
$serv1=$serv[1];
      $usedrams=[];
        $zonenamess=[];
        
        $new='';
        $new1='';
        $dbhost = 'db';
            $dbuser = 'root';
            $dbpass = 'mypass123';
            $dbname='server';
           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            }
            $sql = "SELECT zonename,zonehost,usedram,zoneowner,zoneimage,zoneip from zonedetails1 where zonename='$servname'";
            
           

            $result = mysqli_query($conn, $sql);
            
            
while($row = mysqli_fetch_assoc($result)) {
    // Each individual array is being pushed into the nested array
       
        $zonename=$row["zonename"];
		$hostname=$row["zonehost"];
        $usedram=$row["usedram"];
        $owner=$row["zoneowner"];
        $zoneimage=$row["zoneimage"];
        $zoneip=$row["zoneip"];
		echo "<h1>Details of zone:</h1>";
		echo "<div class=\"memory\">";
        echo "<table style=width:100%>";
        echo "<tr>";
        echo "<th>Zonename</th>";
		echo "<th>Hostname</th>";
        echo "<th>UsedRAM(GB)</th>";
        echo "<th>Zone Owner</th>";
        echo "<th>ZoneImage</th>";
        echo "<th>ZoneIP</th>";
        echo "</tr>";
        echo "<tr>";
		echo "<td align=\"center\">$zonename</td>";
        echo "<td align=\"center\">$hostname</td>";
        echo "<td align=\"center\">$usedram</td>";
        echo "<td align=\"center\">$owner</td>";
        echo "<td align=\"center\">$zoneimage</td>";
        echo "<td align=\"center\">$zoneip</td>";
        echo "</tr>";
        echo "</table>";
		echo "</div><br>";
		echo "<a style=\"font-weight:bold;\" class=\"back\" href=\"listzoneofservers.php?testNum=$serv1\">Back</a>";
		echo "<a style=\"font-weight:bold;\" class=\"home\" href=\"new.php\" >Home</a>";
		mysqli_close($conn);

        #print_r($zonenames);
        #print_r($totalmem);
        #$new = $data[2],$data[3],$data[4];
        #$arrayph = explode(":",$new);
        #foreach($arrayph as $i)
        #{
        #       echo "<li><a href=#>$i</a></li>";
        #}

        #$trimmed = str_replace(":",",",$new);
        #$array1 = array($trimmed);
        #print_r($array1[0]);

#    $the_big_array[] = $data;
  }
  function testfun($country,$servname){
        $usedrams=[];
        $zonenamess=[];
        
        $new='';
        $new1='';
        $dbhost = 'db';
            $dbuser = 'root';
            $dbpass = 'mypass123';
            $dbname='server';
           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            }
            $sql1="SELECT zonename,usedram from zonedetailsback1 where zonename='$servname' order by id DESC LIMIT 10";
            $result1 = mysqli_query($conn, $sql1);
  while($rows = mysqli_fetch_assoc($result1)) {
         
              array_push($zonenamess, $rows["zonename"]);
                array_push($usedrams, $rows["usedram"]);

             
              }

                 $new = "'".implode("','", $zonenamess)."'";
                $new1=implode(",", $usedrams);
                return array($new, $new1);
  // Close the file
  mysqli_close($conn);
#echo "xxx\n";
#print_r($the_big_array[1][0]);
#echo "<pre>";
#var_dump($the_big_array);

#echo "</pre>";

}
?>
<br><br>

<form action=""; method="post" name="myform" id="myform" style="position:relative;left:1000px;">
    
    Graph over Last
  <select name="coder">    
  <option value="" disabled selected>--select--</option> 
       <option value="1 hour">1 hour</option>
        <option value="3 hour">3 hour</option>
        <option value="5 hour">5 hour</option>
        <option value="10 hour">10 hour</option>
        <option value="24 hour">24 hour</option>
        <option value="48 hour">48 hour</option>
    </select>
    <input type="submit" name="submit" value="submit">
  </form>
<div class="container" style="position: relative; height:60vh; width:75vw">
    <canvas id="myChart"></canvas>
  
</div>

 <script>

    let myChart = document.getElementById('myChart').getContext('2d');

    Chart.defaults.global.defaultFontFamily = 'Lato';
    Chart.defaults.global.defaultFontSize = 18;
    Chart.defaults.global.defaultFontColor = '#777';

    let massPopChart = new Chart(myChart, {
      type:'line', // bar, horizontalBar, pie, line, doughnut, radar, polarArea
      data:{
        labels:[<?php echo $x; ?>],
        datasets:[{
          fill:false,
          label:'UsedRAMGB',
          data:[<?php echo $y; ?>],
          //backgroundColor:'green',
          backgroundColor:[
            'rgba(255, 99, 132, 0.6)',
            'rgba(54, 162, 235, 0.6)',
            'rgba(255, 206, 86, 0.6)',
            'rgba(75, 192, 192, 0.6)',
            'rgba(153, 102, 255, 0.6)',
            'rgba(255, 159, 64, 0.6)',
            'rgba(255, 99, 132, 0.6)'
          ],
          borderWidth:1,
          borderColor:'#777',
          hoverBorderWidth:1,
          hoverBorderColor:'#000'
        }]
      },
      options:{
        
        title:{
          display:true,
          text:'RAM usage over intervals',
          fontSize:25
        },
        scales: {
        xAxes: [{barPercentage: 0.3,
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Zonename'
                            }
                        }],
                    yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'UsedRAM in GB'
                            },
                            ticks: {
                                
                               min:0,
                               stepsize:3,
                               
                                
                            }
                        }]
      },

        legend:{
          display:true,
          position:'center',
          labels:{
            fontColor:'#000'
          }
        },
        layout:{
          padding:{
            left:130,
            right:0,
            bottom:50,
            top:0
          }
        },
        tooltips:{
          enabled:true
        }
      }
    });

  </script>

</body>
</html>
