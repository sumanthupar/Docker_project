<html>
<head>
  <title>Webslesson Tutorial | Search HTML Table Data by using JQuery</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
            
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  
  <script>
history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
     $(document).ready(function(){  
           $('#search').keyup(function(){  
                search_table($(this).val());  
           });  
           function search_table(value){  
                $('#employee_table tr').each(function(){  
                     var found = 'false';  
                     $(this).each(function(){  
                          if($(this).text().toLowerCase().indexOf(value.toLowerCase()) >= 0)  
                          {  
                               found = 'true';  
                          }  
                     });  
                     if(found == 'true')  
                     {  
                          $(this).show();  
                     }  
                     else  
                     {  
                          $(this).hide();  
                     }  
                });  
           }  
      });  
  </script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

.home{
  color:black;
  display:inline-block;
  background: rgba(0,0,0, 0.3);
  padding:6px 16px;
 
  font-weight: bold;
  float:right;
}
a.home:link,a.home:visited
{
  color:black;
}
table, th, td {
border: 1px solid black;

}


body {
  font-family: "Lato", sans-serif;
background: rgba(0,0,0, 0.01);
  
  

a {
  float:right;
  
}
}
</style>
<body>

<h1>All zone Details:</h1>
<a href="new.php" class="home">Home</a>
<br>
<br>
<div align="center" >
<input type="text" placeholder="Search" name="" id="search" style="width:25vw;border: 1px solid black">
</div>
<br>

      
 
    <div class="table-responsive" > 
      <table class="table table-bordered" style=width:100%>
       <tr>
        <th align="center" col width="55">Sl.No</th>
         <th align="center" col width="183">Zonename</th>
        <th align="center" col width="247">Hostname</th>
        <th align="center" col width="155">UsedRAM(GB)</th>
        <th align="center" col width="173">Zone Owner</th>
        <th align="center" col width="232">ZoneImage</th>
        <th align="center">ZoneIP</th>
      </tr>

      </table>
      <table class="table table-bordered" style=width:100% id="employee_table">
  

      
<?php
$i=0;
$dbhost = 'db';
            $dbuser = 'root';
            $dbpass = 'mypass123';
            $dbname='server';
           $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
           if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            }
             $sql = "SELECT zonename,zonehost,usedram,zoneowner,zoneimage,zoneip from zonedetails1";
             $result = mysqli_query($conn, $sql);

             while($row = mysqli_fetch_assoc($result)) {
    // Each individual array is being pushed into the nested array
       
        $zonename=$row["zonename"];
        $hostname=$row["zonehost"];
        $usedram=$row["usedram"];
        $owner=$row["zoneowner"];
        $zoneimage=$row["zoneimage"];
        $zoneip=$row["zoneip"];
        
        echo "<tr>";
        echo "<td align=\"center\" col width=\"55\">$i</td>";
        echo "<td align=\"center\" col width=\"183\">$zonename</td>";
        echo "<td align=\"center\" col width=\"247\">$hostname</td>";
        echo "<td align=\"center\" col width=\"155\">$usedram</td>";
        echo "<td align=\"center\" col width=\"173\">$owner</td>";
        echo "<td align=\"center\" col width=\"232\">$zoneimage</td>";
        echo "<td align=\"center\" >$zoneip</td>";
        echo "</tr>";
       
       $i++; 

        #print_r($zonenames);
        #print_r($totalmem);
        #$new = $data[2],$data[3],$data[4];
        #$arrayph = explode(":",$new);
        #foreach($arrayph as $i)
        #{
        #       echo "<li><a href=#>$i</a></li>";
        #}

        #$trimmed = str_replace(":",",",$new);
        #$array1 = array($trimmed);
        #print_r($array1[0]);

#    $the_big_array[] = $data;
  }

  // Close the file
  mysqli_close($conn);
#echo "xxx\n";
#print_r($the_big_array[1][0]);
#echo "<pre>";
#var_dump($the_big_array);

#echo "</pre>";
  
?>
</table>
</div><br>

<script>
     $(document).ready(function(){  
           $('#search').keyup(function(){  
                search_table($(this).val());  
           });  
           function search_table(value){  
                $('#employee_table tr').each(function(){  
                     var found = 'false';  
                     $(this).each(function(){  
                          if($(this).text().toLowerCase().indexOf(value.toLowerCase()) >= 0)  
                          {  
                               found = 'true';  
                          }  
                     });  
                     if(found == 'true')  
                     {  
                          $(this).show();  
                     }  
                     else  
                     {  
                          $(this).hide();  
                     }  
                });  
           }  
      });  
</script>
</body>
</html>
